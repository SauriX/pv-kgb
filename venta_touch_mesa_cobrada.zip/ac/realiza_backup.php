<?
set_time_limit(0);
ignore_user_abort(1);

//include('../includes/db.php');
include('../includes/backup.php');

backup();
