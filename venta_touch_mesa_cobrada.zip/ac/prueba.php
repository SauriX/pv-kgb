<?php

	include('../includes/session.php');	
	include('../includes/db.php');
	include('../includes/impresora.php');
	


	
	$id_corte=5;

	




	
	echo (imprimir_corte($id_corte));
	









		