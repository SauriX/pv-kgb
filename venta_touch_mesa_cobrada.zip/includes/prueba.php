esc_pos_line($printer, "PITAYA                        1   18.00    18.00");
esc_pos_line($printer, "LA TRIO                       1   38.00    38.00");
esc_pos_line($printer, "CHORIZO                       1   10.00    10.00");
esc_pos_line($printer, "LA TRIO                         1   38.00    38.00");
esc_pos_line($printer, "LA TRIO                          1   38.00    38.00");
esc_pos_line($printer, "LA TRIO               1   38.00    38.00");
esc_pos_line($printer, "LA TRIO                 1   38.00    38.00");
esc_pos_line($printer, "PEPERONI                1   10.00    10.00");