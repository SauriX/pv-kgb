<?
include("backup.php");
backup();