<?php
error_reporting(0);

/* /*$servidor="localhost";
$usuario="root";s
$clave="root";
$base="vendefacil_restaurante";



$servidorl="conexiadb.cu7qst8jqevg.us-east-2.rds.amazonaws.com";
$usuariol="root";
$clavel="conexia2019";
$basel="kgb_club";
$enlace=mysql_connect($servidorl,$usuariol,$clavel);
 */





?>