esc_pos_line($printer, "SENCILLA             2   38.00    76.00");
esc_pos_line($printer, "(EXTRA)SALAMI        1   10.00    10.00");
esc_pos_line($printer, "(EXTRA)PEPINILLO     1   10.00    10.00");