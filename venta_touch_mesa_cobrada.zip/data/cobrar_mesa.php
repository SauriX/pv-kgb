<div class="row">
	<div class="col-md-6">
		<div class="input-group col-md-12 mb20">
			<span class="input-group-addon f18">Recibe: &nbsp;</span>
			<input type="text" autocomplete="off" id="recibe" name="recibe" class="form-control total">
		</div>
		
		<div class="input-group col-md-12 mb20">
			<span class="input-group-addon f18">Consumo: &nbsp;&nbsp;&nbsp;&nbsp;</span>
			<input type="text" id="consumo" class="form-control total" readonly="1" value="0.00">
		</div>
		
		<div class="input-group col-md-12">
			<span class="input-group-addon f18">Cambio: </span>
			<input type="text" id="cambio" class="form-control total" readonly="1" value="">
		</div>
		
		<hr>
	</div>
	<div class="col-md-6"></div>
</div>





<!-- Pagar Mesa 5


Recibe: 500.00 input
Consumo: 149.00 
Cambio: 351.00

——

Factura: select: vacio·si·no
Documentos: 1
Monto a Facturar: 149.00
Metodo de Pago:
Número de Cuenta:
Observaciones:
-->