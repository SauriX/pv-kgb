

/********************************************/
/**   VENDEFACIL 2.0 | LISTA DE PRODUCTOS  **/
/********************************************/
/* Ultima actualizacion: 2019-09-27 14:04:30*/
/********************************************/

"PAN" : { id_base: "1" },"CARNE" : { id_base: "2" },"QUESO" : { id_base: "3" },"SALAMI" : { id_base: "4" },"PEPERONI" : { id_base: "5" },"CHORIZO" : { id_base: "6" },"JALAPENO" : { id_base: "7" },"MOZARELA" : { id_base: "8" },"PHILADELFIA" : { id_base: "9" },"SALCHICHA PARA ASAR" : { id_base: "10" },"TOCINO" : { id_base: "11" },"AGUACATE" : { id_base: "12" },"PINA" : { id_base: "13" },"CHAMPINON" : { id_base: "14" },"LEGUMBRES" : { id_base: "15" },"GOUDA" : { id_base: "16" },"CHIHUAHUA" : { id_base: "17" },"MANCHEGO" : { id_base: "18" },"SALCHICHA" : { id_base: "19" },"PASTOR" : { id_base: "20" },"POLLO" : { id_base: "21" },"PEPINILLOS" : { id_base: "22" },"ARRACHERA" : { id_base: "23" },"QUESO DE BOLA" : { id_base: "24" },"AROS DE CEBOLLA" : { id_base: "25" },"PAPA" : { id_base: "27" }

/********************************************/
/**       TERMINA LISTA DE PRODUCTOS       **/
/********************************************/

