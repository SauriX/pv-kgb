/* Custom JavaScript */
$(document).ready(function($) {
	$('input, textarea').placeholder();
});

